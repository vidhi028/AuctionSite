package com.hsbc.auction.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.hsbc.auction.helpers.DBHelper;
import com.hsbc.auction.models.User;

public class UserDaoImpl implements UserDao{
	
	private Connection conn;
	private PreparedStatement pre;
	private ResultSet resultSet;
	private java.sql.Statement stmt;
	private boolean status;
	private ResourceBundle resourceBundle;
	
	

	public UserDaoImpl() {
		try {
			conn=DBHelper.getConnection();
			System.out.println("Connection Created....");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getErrorCode());
		}

		resourceBundle=ResourceBundle.getBundle("com/hsbc/auction/resources/db");
	}
	

	@Override
	public boolean addUser(List<User> userList) throws SQLException {
		// TODO Auto-generated method stub
		int[] results= {};
		try {
			conn=DBHelper.getConnection();
			pre=conn.prepareStatement(resourceBundle.getString("addUsers"));
			for(User user :userList)
			{
				pre.setInt(1,user.getUniqueId());
				pre.setString(2, user.getName());
				pre.setDate(3, Date.valueOf(user.getDob()));
				pre.setString(4, user.getEmail());
				pre.setLong(5, user.getContactNo());
				pre.setString(6, user.getUserName());
				pre.setString(7, user.getPassword());
				pre.setString(8, user.getAddress());
				pre.setString(9, user.getUserType());
				pre.setDouble(10, user.getWalletAmount());

				pre.addBatch();
			}
			results=pre.executeBatch();
			conn.commit();
			status=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getErrorCode());
			conn.rollback();
			throw new SQLException("Connection Error Occurred");
		}
		finally
		{
			conn.close();
		}
		
		return status;
	}

	@Override
	public List<User> getAllUsers() throws SQLException {
		// TODO Auto-generated method stub
		
		List<User> userList=new ArrayList<User>();

		try {
			conn=DBHelper.getConnection();
			
			pre=conn.prepareStatement(resourceBundle.getString("addUsers"));

			
			/*
			 * stmt=conn.createStatement();
			 * resultSet=stmt.executeQuery(resourceBundle.getString("getUsers"));
			 * while(resultSet.next()) { user=new User();
			 * 
			 * user.setUniqueId(resultSet.getInt(1)); user.setName(resultSet.getString(2));
			 * 
			 * //user.setDob(Date.valueOf(resultSet.getDate(3)));
			 * 
			 * user.setEmail(resultSet.getString(4));
			 * user.setContactNo(resultSet.getLong(5));
			 * user.setUserName(resultSet.getString(6));
			 * user.setPassword(resultSet.getString(7));
			 * user.setAddress(resultSet.getString(8));
			 * user.setUserType(resultSet.getString(9));
			 * user.setWalletAmount(resultSet.getDouble(10));
			 * 
			 * userList.add(user); }
			 */
			
			for(User user :userList)
			{
				pre.setInt(1,user.getUniqueId());
				pre.setString(2, user.getName());
				pre.setDate(3, Date.valueOf(user.getDob()));
				pre.setString(4, user.getEmail());
				pre.setLong(5, user.getContactNo());
				pre.setString(6, user.getUserName());
				pre.setString(7, user.getPassword());
				pre.setString(8, user.getAddress());
				pre.setString(9, user.getUserType());
				pre.setDouble(10, user.getWalletAmount());

			}
			pre.executeQuery();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getErrorCode());
			throw new SQLException("Connection Error Occurred");
		}
		finally
		{
			conn.close();
		}
		
		
		return userList;
	}

}
