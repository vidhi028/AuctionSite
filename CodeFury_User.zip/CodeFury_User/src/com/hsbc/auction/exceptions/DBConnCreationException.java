package com.hsbc.auction.exceptions;

public class DBConnCreationException extends Exception{
	
	public DBConnCreationException(String message) {
		super(message);
	}

}
