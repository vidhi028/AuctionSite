package com.hsbc.auction.utility;

public class UserView {

}
